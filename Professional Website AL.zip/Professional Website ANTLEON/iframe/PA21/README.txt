The only link that works on the drop down is the ALBUMS I LIKE
page which is based off the works page of the template